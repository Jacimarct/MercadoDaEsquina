-- src/main/resources/data.sql
INSERT INTO produto (nome, tipo, preco, medida) VALUES ('Abacaxi', 'Fruta', 3.5, 'unidade');
INSERT INTO produto (nome, tipo, preco, medida) VALUES ('Laranja', 'Fruta', 2.0, 'kg');
INSERT INTO produto (nome, tipo, preco, medida) VALUES ('Alface', 'Verdura', 1.5, 'unidade');

INSERT INTO cliente (nome, endereco, cidade) VALUES ('João Silva', 'Rua das Flores, 123', 'São Paulo');
INSERT INTO cliente (nome, endereco, cidade) VALUES ('Maria Oliveira', 'Avenida Paulista, 456', 'São Paulo');
