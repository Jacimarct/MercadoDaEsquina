-- src/main/resources/data.sql
INSERT INTO product (name, price, unit) VALUES ('Abacaxi', 3.5, 'unidade');
INSERT INTO product (name, price, unit) VALUES ('Laranja', 2.0, 'kg');
INSERT INTO product (name, price, unit) VALUES ('Alface',  1.5, 'unidade');

--INSERT INTO cliente (nome, endereco, cidade) VALUES ('João Silva', 'Rua das Flores, 123', 'São Paulo');
--INSERT INTO cliente (nome, endereco, cidade) VALUES ('Maria Oliveira', 'Avenida Paulista, 456', 'São Paulo');
