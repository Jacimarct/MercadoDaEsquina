//package com.mercado.mercadoDaEsquina.controller;
//
//import com.mercado.mercadoDaEsquina.model.Cliente;
//import com.mercado.mercadoDaEsquina.service.ClienteService;
//import org.springframework.beans.factory.annotation.Autowired;
//import org.springframework.web.bind.annotation.*;
//
//import java.util.List;
//
//@RestController
//@RequestMapping("/clientes")
//public class ClienteController {
//    @Autowired
//    private ClienteService clienteService;
//
//    @GetMapping
//    public List<Cliente> listarTodos() {
//        return clienteService.listarTodos();
//    }
//
//    @PostMapping
//    public Cliente salvar(@RequestBody Cliente cliente) {
//        return clienteService.salvar(cliente);
//    }
//
//    // Outros endpoints, se necessário
//}
