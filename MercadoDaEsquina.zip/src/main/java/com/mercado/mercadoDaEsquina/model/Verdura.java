//package com.mercado.mercadoDaEsquina.model;
//
//import jakarta.persistence.*;
//
////import java.math.BigDecimal;
//
//@Entity(name = "tb_verdura")
//public class Verdura  extends Produto {
//
//    // Getters e Setters
//}
