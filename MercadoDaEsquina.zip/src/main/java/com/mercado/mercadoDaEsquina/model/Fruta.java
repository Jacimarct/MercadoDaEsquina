//package com.mercado.mercadoDaEsquina.model;
//
//import jakarta.persistence.*;
//
//@Entity(name = "tb_fruta")
//public class Fruta extends Produto {
//
//    // Getters e Setters
//}
