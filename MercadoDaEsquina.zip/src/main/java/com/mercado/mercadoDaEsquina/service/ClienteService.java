//package com.mercado.mercadoDaEsquina.service;
//
//import com.mercado.mercadoDaEsquina.model.Cliente;
//import com.mercado.mercadoDaEsquina.repository.ClienteRepository;
//import org.springframework.beans.factory.annotation.Autowired;
//import org.springframework.stereotype.Service;
//
//import java.util.List;
//
//@Service
//public class ClienteService {
//    @Autowired
//    private ClienteRepository clienteRepository;
//
//    public List<Cliente> listarTodos() {
//        return clienteRepository.findAll();
//    }
//
//    public Cliente salvar(Cliente cliente) {
//        return clienteRepository.save(cliente);
//    }
//
//    // Outros métodos, se necessário
//}
